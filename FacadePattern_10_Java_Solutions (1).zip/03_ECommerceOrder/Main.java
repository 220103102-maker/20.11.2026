public class Main {
 public static void main(String[] args) {
  OrderFacade f=new OrderFacade(); System.out.println(f.placeOrder("COFFEE-1",2,"VISA-1234","Almaty"));
 }
}
