class InventoryManager { boolean available(String id,int q){System.out.println("Checking stock for "+id);return q>0&&q<=10;} void reserve(String id,int q){System.out.println("Reserved "+q+" x "+id);} }
class PaymentGateway { boolean charge(String info,double total){System.out.println("Charging $"+total);return info!=null&&!info.isBlank();} }
class ShippingService { void dispatch(String id,int q,String address){System.out.println("Shipping "+q+" x "+id+" to "+address);} }
public class OrderFacade {
 private final InventoryManager inventory=new InventoryManager();private final PaymentGateway payment=new PaymentGateway();private final ShippingService shipping=new ShippingService();
 public boolean placeOrder(String productId,int quantity,String paymentInfo,String address){if(productId==null||address==null||!inventory.available(productId,quantity)){System.out.println("Order rejected: stock/details");return false;}double total=quantity*25.0;if(!payment.charge(paymentInfo,total)){System.out.println("Payment failed");return false;}inventory.reserve(productId,quantity);shipping.dispatch(productId,quantity,address);return true;}
}
