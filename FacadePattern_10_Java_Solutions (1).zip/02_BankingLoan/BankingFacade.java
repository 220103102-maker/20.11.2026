class AccountService { boolean active(String id){System.out.println("Checking account "+id);return id!=null&&!id.isBlank();} }
class CreditScoreService { int score(String id){System.out.println("Checking credit score");return 720;} }
class LoanLedger { void record(String id,double amount){System.out.println("Recorded loan $"+amount+" for "+id);} }
public class BankingFacade {
 private final AccountService accounts=new AccountService(); private final CreditScoreService credit=new CreditScoreService(); private final LoanLedger ledger=new LoanLedger();
 public boolean applyForLoan(String customerId,double amount){if(amount<=0||!accounts.active(customerId)){System.out.println("Loan rejected");return false;} int score=credit.score(customerId); if(score<650){System.out.println("Credit score too low");return false;} ledger.record(customerId,amount);System.out.println("Loan approved");return true;}
}
