public class Main {
 public static void main(String[] args) {
  BankingFacade f=new BankingFacade(); System.out.println(f.applyForLoan("CUST-101",15000));
 }
}
