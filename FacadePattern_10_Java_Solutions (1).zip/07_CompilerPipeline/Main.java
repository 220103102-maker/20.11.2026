public class Main {
 public static void main(String[] args) {
  CompilerFacade f=new CompilerFacade(); System.out.println(f.compile("int total = 10;"));
 }
}
