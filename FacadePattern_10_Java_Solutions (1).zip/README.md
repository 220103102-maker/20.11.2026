# Facade Design Pattern in Java — 10 Coding Solutions

Each numbered folder is an independent Java example for one question in the supplied PDF.
Each folder contains the facade and its subsystem classes in one Java source file, plus Main.java.

## Run
Open a terminal inside one numbered folder:
    javac *.java
    java Main

Requires Java 11 or newer. These are educational simulations; they do not connect to real banks,
payment providers, travel services, cloud clusters, or media/PDF processing systems.
