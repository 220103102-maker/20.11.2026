public class Main {
 public static void main(String[] args) {
  HomeTheaterFacade f=new HomeTheaterFacade(); f.watchMovie("Inception"); f.endMovie();
 }
}
