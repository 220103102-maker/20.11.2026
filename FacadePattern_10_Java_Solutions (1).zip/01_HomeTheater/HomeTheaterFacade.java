class Amplifier { void on(){System.out.println("Amplifier ON");} void setVolume(int v){System.out.println("Volume "+v);} void off(){System.out.println("Amplifier OFF");} }
class Projector { void on(){System.out.println("Projector ON");} void wide(){System.out.println("Widescreen mode");} void off(){System.out.println("Projector OFF");} }
class StreamingPlayer { void on(){System.out.println("Player ON");} void play(String m){System.out.println("Playing "+m);} void stop(){System.out.println("Playback stopped");} void off(){System.out.println("Player OFF");} }
class TheaterLights { void dim(int n){System.out.println("Lights dimmed to "+n+"%");} void on(){System.out.println("Lights ON");} }
public class HomeTheaterFacade {
 private final Amplifier a=new Amplifier(); private final Projector p=new Projector(); private final StreamingPlayer s=new StreamingPlayer(); private final TheaterLights l=new TheaterLights();
 public void watchMovie(String movie){l.dim(10);p.on();p.wide();a.on();a.setVolume(5);s.on();s.play(movie);}
 public void endMovie(){s.stop();s.off();a.off();p.off();l.on();}
}
