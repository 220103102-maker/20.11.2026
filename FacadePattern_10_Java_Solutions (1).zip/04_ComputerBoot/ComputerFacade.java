class CPU { void freeze(){System.out.println("CPU freeze");} void jump(long p){System.out.println("CPU jump to "+p);} void execute(){System.out.println("CPU execute");} }
class Memory { void load(long p,byte[] d){System.out.println("Loading "+d.length+" bytes into memory");} }
class HardDrive { byte[] read(long sector,int size){System.out.println("Reading disk");return new byte[size];} }
public class ComputerFacade {
 private final CPU cpu=new CPU();private final Memory memory=new Memory();private final HardDrive disk=new HardDrive();
 public void start(){cpu.freeze();byte[] boot=disk.read(0,1024);memory.load(0,boot);cpu.jump(0);cpu.execute();System.out.println("Computer started");}
}
