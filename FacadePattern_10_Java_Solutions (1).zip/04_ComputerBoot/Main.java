public class Main {
 public static void main(String[] args) {
  ComputerFacade f=new ComputerFacade(); f.start();
 }
}
