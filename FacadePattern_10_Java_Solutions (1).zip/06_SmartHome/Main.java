public class Main {
 public static void main(String[] args) {
  SmartHomeFacade f=new SmartHomeFacade(); f.activateMorningMode(); f.activateNightMode();
 }
}
