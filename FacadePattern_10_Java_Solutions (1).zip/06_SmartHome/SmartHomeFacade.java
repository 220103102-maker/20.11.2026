class SmartThermostat { void setTemperature(int t){System.out.println("Temperature "+t+"C");} }
class AutomatedBlinds { void open(){System.out.println("Blinds open");} void close(){System.out.println("Blinds closed");} }
class CoffeeMaker { void brew(){System.out.println("Coffee brewing");} void off(){System.out.println("Coffee maker off");} }
class SecurityAlarm { void arm(){System.out.println("Alarm armed");} void disarm(){System.out.println("Alarm disarmed");} }
public class SmartHomeFacade {
 private final SmartThermostat thermostat=new SmartThermostat();private final AutomatedBlinds blinds=new AutomatedBlinds();private final CoffeeMaker coffee=new CoffeeMaker();private final SecurityAlarm alarm=new SecurityAlarm();
 public void activateMorningMode(){alarm.disarm();blinds.open();thermostat.setTemperature(22);coffee.brew();}
 public void activateNightMode(){coffee.off();blinds.close();thermostat.setTemperature(19);alarm.arm();}
}
