public class Main {
 public static void main(String[] args) {
  ReportFacade f=new ReportFacade(); System.out.println(f.generateReport("RPT-001"));
 }
}
