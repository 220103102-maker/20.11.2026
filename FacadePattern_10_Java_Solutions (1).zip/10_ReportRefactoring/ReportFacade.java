class DatabaseConnection { void connect(){System.out.println("DB connected");} String fetch(String id){System.out.println("Fetching "+id);return "data:"+id;} void disconnect(){System.out.println("DB disconnected");} }
class QueryExecutor { String execute(String d){System.out.println("Executing query");return d+"-queried";} }
class DataFormatter { String format(String d){System.out.println("Formatting data");return "FORMATTED:"+d;} }
class PdfExporter { String export(String d){System.out.println("Exporting PDF");return "report.pdf";} }
public class ReportFacade {
 private final DatabaseConnection db=new DatabaseConnection();private final QueryExecutor query=new QueryExecutor();private final DataFormatter formatter=new DataFormatter();private final PdfExporter pdf=new PdfExporter();
 public String generateReport(String reportId){if(reportId==null||reportId.isBlank())throw new IllegalArgumentException("Report ID required");db.connect();try{return pdf.export(formatter.format(query.execute(db.fetch(reportId))));}finally{db.disconnect();}}
}
