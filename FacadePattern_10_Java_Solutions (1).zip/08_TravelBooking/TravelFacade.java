class FlightBooking { boolean book(String d,String s){System.out.println("Flight to "+d+" on "+s);return true;} void cancel(String d){System.out.println("Flight cancelled");} }
class HotelReservation { boolean reserve(String d,String s,String e){System.out.println("Hotel in "+d+" "+s+"-"+e);return true;} void cancel(String d){System.out.println("Hotel cancelled");} }
class CarRental { boolean rent(String d,String s,String e){System.out.println("Car in "+d+" "+s+"-"+e);return true;} }
public class TravelFacade {
 private final FlightBooking flight=new FlightBooking();private final HotelReservation hotel=new HotelReservation();private final CarRental car=new CarRental();
 public boolean bookTrip(String destination,String startDate,String endDate){if(destination==null||destination.isBlank()||startDate==null||endDate==null)return false;if(!flight.book(destination,startDate))return false;if(!hotel.reserve(destination,startDate,endDate)){flight.cancel(destination);return false;}if(!car.rent(destination,startDate,endDate)){hotel.cancel(destination);flight.cancel(destination);return false;}System.out.println("Trip booked");return true;}
}
