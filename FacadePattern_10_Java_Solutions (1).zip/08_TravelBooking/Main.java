public class Main {
 public static void main(String[] args) {
  TravelFacade f=new TravelFacade(); System.out.println(f.bookTrip("Istanbul","2026-12-10","2026-12-17"));
 }
}
