public class Main {
 public static void main(String[] args) {
  DeploymentFacade f=new DeploymentFacade(); System.out.println(f.deployService("https://github.com/example/app.git","main"));
 }
}
