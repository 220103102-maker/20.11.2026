class CodeRepository { boolean checkout(String url,String branch){System.out.println("Checkout "+branch+" from "+url);return url!=null&&url.startsWith("https://")&&branch!=null&&!branch.isBlank();} }
class SecurityScanner { boolean scan(){System.out.println("Security scan passed");return true;} }
class ContainerBuilder { String build(){System.out.println("Building container");return "service:latest";} }
class ClusterDeployer { void deploy(String image){System.out.println("Deploying "+image);} }
public class DeploymentFacade {
 private final CodeRepository repo=new CodeRepository();private final SecurityScanner scanner=new SecurityScanner();private final ContainerBuilder builder=new ContainerBuilder();private final ClusterDeployer deployer=new ClusterDeployer();
 public boolean deployService(String repoUrl,String branch){if(!repo.checkout(repoUrl,branch))return false;if(!scanner.scan())return false;String image=builder.build();deployer.deploy(image);return true;}
}
