public class Main {
 public static void main(String[] args) {
  VideoConverterFacade f=new VideoConverterFacade(); System.out.println(f.convert("movie.avi","mp4"));
 }
}
