class VideoFile { final String name; VideoFile(String n){name=n;} }
class CodecFactory { String extract(VideoFile f){String ext=f.name.contains(".")?f.name.substring(f.name.lastIndexOf('.')+1):"unknown";System.out.println("Extracting "+ext+" codec");return ext+"-codec";} }
class BitrateReader { String read(VideoFile f,String c){System.out.println("Reading "+f.name+" with "+c);return "video-data";} String convert(String d,String fmt){System.out.println("Converting to "+fmt);return d+"-"+fmt;} }
class AudioMixer { String fix(String d){System.out.println("Mixing audio");return d+"-audio";} }
public class VideoConverterFacade {
 private final CodecFactory codecs=new CodecFactory();private final BitrateReader reader=new BitrateReader();private final AudioMixer audio=new AudioMixer();
 public String convert(String filename,String targetFormat){if(filename==null||targetFormat==null||filename.isBlank()||targetFormat.isBlank())throw new IllegalArgumentException("Filename and format required");VideoFile f=new VideoFile(filename);String codec=codecs.extract(f);String data=reader.read(f,codec);data=reader.convert(data,targetFormat);audio.fix(data);String base=filename.contains(".")?filename.substring(0,filename.lastIndexOf('.')):filename;return base+"."+targetFormat;}
}
