// Subsystem 2: Drives the rotating perforated steel drum that tumbles the beans.
public class RoastingDrumMotor {
    private int currentRpm = 0;

    // Starts the drum motor at the requested RPM (valid operating range: 30 to 65 RPM).
    public void startRotation(int targetRpm) {
        if (targetRpm < 30 || targetRpm > 65) {
            throw new IllegalArgumentException("Drum RPM must be between 30 and 65.");
        }
        this.currentRpm = targetRpm;
        System.out.println("[DrumMotor] Drum rotating at " + currentRpm + " RPM.");
    }

    // Adjusts speed mid-roast.
    public void adjustRpm(int newRpm) {
        if (currentRpm == 0) {
            throw new IllegalStateException("Cannot adjust RPM while drum motor is stopped.");
        }
        startRotation(newRpm);
    }

    // Brings the roasting drum to a complete halt.
    public void stopRotation() {
        this.currentRpm = 0;
        System.out.println("[DrumMotor] Drum rotation STOPPED (0 RPM).");
    }

    public boolean isSpinning() {
        return currentRpm > 0;
    }
}
