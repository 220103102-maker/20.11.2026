// Facade: Provides a safe, high-level API over the five stateful roaster subsystems.
public class CoffeeRoasterFacade {

    private final BeanHopperGate hopperGate;
    private final RoastingDrumMotor drumMotor;
    private final HeatingChamber heatingChamber;
    private final CoolingTraySystem coolingTray;
    private final TelemetryLogger logger;

    // Initializes all hardware controllers in their default idle states.
    public CoffeeRoasterFacade() {
        this.hopperGate = new BeanHopperGate();
        this.drumMotor = new RoastingDrumMotor();
        this.heatingChamber = new HeatingChamber();
        this.coolingTray = new CoolingTraySystem();
        this.logger = new TelemetryLogger();
    }

    /**
     * Executes a complete, safety-interlocked coffee roasting cycle.
     *
     * @param beanOrigin        Name/origin of the coffee beans
     * @param batchGrams        Weight of green beans in grams (250 to 5000)
     * @param drumRpm           Drum rotation speed in RPM (30 to 65)
     * @param targetTempCelsius Peak roast chamber temperature (160 to 245)
     * @return true if the batch roasted and cooled cleanly; false if aborted
     */
    public boolean runRoastBatch(String beanOrigin,
                                 int batchGrams,
                                 int drumRpm,
                                 int targetTempCelsius) {
        try {
            // 1. Reset telemetry and log the batch start.
            logger.resetBatchLog();
            logger.logState("BATCH", "Starting roast batch for: " + beanOrigin);

            // 2. Load beans into the hopper.
            hopperGate.loadGreenBeans(batchGrams);
            logger.logState("HOPPER", "Loaded " + batchGrams + "g of green beans.");

            // 3. Start the drum before dropping beans.
            drumMotor.startRotation(drumRpm);
            logger.logState("DRUM", "Drum started at " + drumRpm + " RPM.");

            // 4. Charge the drum and immediately close the hopper gate.
            hopperGate.openGate();
            hopperGate.closeGate();
            logger.logState("HOPPER", "Beans transferred; hopper gate sealed.");

            // 5. Ignite burner only after confirming that the drum is spinning.
            heatingChamber.igniteBurner(drumMotor.isSpinning());
            logger.logState("HEATING", "Gas burner ignited.");

            // 6. Heat to the requested roast profile temperature.
            heatingChamber.heatToTarget(targetTempCelsius);
            logger.logState("ROAST", "Roasting at target temperature: " + targetTempCelsius + "C.");

            // 7. Extinguish burner before discharging hot beans.
            heatingChamber.extinguishBurner();
            logger.logState("HEATING", "Burner extinguished.");

            // 8. Start cooling airflow before opening the discharge door.
            coolingTray.startCoolingFan();
            coolingTray.openDischargeDoor(heatingChamber.isBurnerIgnited());
            logger.logState("COOLING", "Beans transferred to cooling tray.");

            // 9. Stop drum, finish cooling, and complete the batch.
            drumMotor.stopRotation();
            coolingTray.finishCoolingCycle();
            logger.logState("BATCH", "Roast batch completed successfully.");
            return true;

        } catch (RuntimeException ex) {
            emergencyAbort(ex.getMessage());
            return false;
        }
    }

    // Preset wrapper for a light roast (55 RPM, 196°C).
    public boolean roastLightProfile(String beanOrigin, int batchGrams) {
        return runRoastBatch(beanOrigin, batchGrams, 55, 196);
    }

    // Preset wrapper for a dark roast (42 RPM, 230°C).
    public boolean roastDarkProfile(String beanOrigin, int batchGrams) {
        return runRoastBatch(beanOrigin, batchGrams, 42, 230);
    }

    /**
     * Safe shutdown sequence invoked whenever a hardware check or parameter fails.
     * Leaves the burner off, hopper closed, drum stopped, and cooling tray idle.
     */
    public void emergencyAbort(String reason) {
        logger.logState("ABORT", "Emergency shutdown triggered: " + reason);
        heatingChamber.extinguishBurner();
        hopperGate.closeGate();
        drumMotor.stopRotation();
        coolingTray.finishCoolingCycle();
    }
}
